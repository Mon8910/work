package com.example.workapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    Spinner spn1 ,spn2, spn3,spn4,spn5 , spn6 , spn7,spn8,spn9,spn10,a1c,fpg,ogtt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spn1=findViewById(R.id.sp11);
        spn2=findViewById(R.id.sp2);
        spn3=findViewById(R.id.sp3);
        spn4=findViewById(R.id.sp4);
        spn5=findViewById(R.id.sp5);
        spn6=findViewById(R.id.sp6);
        spn7=findViewById(R.id.sp7);
        spn8=findViewById(R.id.sp8);
        spn9=findViewById(R.id.sp9);
        spn10=findViewById(R.id.sp10);
        a1c=findViewById(R.id.AIC);
        fpg=findViewById(R.id.FPG);
        ogtt=findViewById(R.id.OGTT);


        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,R.array.gender, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spn1.setAdapter(adapter);
        ArrayAdapter<CharSequence> addapter=ArrayAdapter.createFromResource(this,R.array.age, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spn2.setAdapter(addapter);

        ArrayAdapter<CharSequence> adddapter=ArrayAdapter.createFromResource(this,R.array.history, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spn3.setAdapter(adddapter);
        spn4.setAdapter(adddapter);
        spn8.setAdapter(adddapter);
        spn9.setAdapter(adddapter);
        spn10.setAdapter(adddapter);



        ArrayAdapter<CharSequence> addddapter=ArrayAdapter.createFromResource(this,R.array.HDL, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spn5.setAdapter(addddapter);
        ArrayAdapter<CharSequence> adapt=ArrayAdapter.createFromResource(this,R.array.pressure, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spn6.setAdapter(adapt);
        ArrayAdapter<CharSequence> addapt=ArrayAdapter.createFromResource(this,R.array.Triglyceride, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spn7.setAdapter(addapt);

        //SUGAR YA RAMDAN HA
        ArrayAdapter<CharSequence> A1C=ArrayAdapter.createFromResource(this,R.array.A1C, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        a1c.setAdapter(A1C);

        ArrayAdapter<CharSequence> FPG=ArrayAdapter.createFromResource(this,R.array.FPG, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fpg.setAdapter(FPG);

        ArrayAdapter<CharSequence> OGTT=ArrayAdapter.createFromResource(this,R.array.OGTTT, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ogtt.setAdapter(OGTT);






    }
}