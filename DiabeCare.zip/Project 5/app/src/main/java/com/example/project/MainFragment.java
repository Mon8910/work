package com.example.project;

import android.animation.ObjectAnimator;
import android.graphics.Color;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainFragment extends Fragment {

    int counter=0;
    Button btn;
    Spinner sp1,sp10,sp12,sp13,sp14;
    LinearLayout hidden2,hidden3;
    CardView hidden1;
    EditText e1,e2,e3;
    TextView t1,t2,t3,imgText;
    MainActivity mainActivity;
    ScrollView sc;
    ImageView image;
    boolean imageVis=false;


    public void setActivity(MainActivity mainActivity){
        this.mainActivity=mainActivity;
    }

    private void disableEnableControls (boolean enable, ViewGroup test){
        for (int i = 0; i < test.getChildCount(); i++){
            View child = test.getChildAt(i);
            child.setEnabled(enable);
            if (child instanceof ViewGroup){
                disableEnableControls(enable, (ViewGroup)child);
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_main, container, false);
        sp1 =view.findViewById(R.id.sp1);
        sp10=view.findViewById(R.id.sp10);
        sp12=view.findViewById(R.id.sp12);
        sp13=view.findViewById(R.id.sp13);
        sp14=view.findViewById(R.id.sp14);
        e1=view.findViewById(R.id.e1);
        e2=view.findViewById(R.id.e2);
        e3=view.findViewById(R.id.e3);
        t1=view.findViewById(R.id.t1);
        t2=view.findViewById(R.id.t2);
        t3=view.findViewById(R.id.t3);
        imgText=view.findViewById(R.id.imgText);
        sc=view.findViewById(R.id.sc);
        btn=view.findViewById(R.id.startTest);
        hidden1 = view.findViewById(R.id.hidden1);
        hidden2 = view.findViewById(R.id.hidden2);
        hidden3 = view.findViewById(R.id.hidden3);
        image=view.findViewById(R.id.image);
        ObjectAnimator objectAnimator = ObjectAnimator.ofInt(sc, "scrollY", 0).setDuration(350);

        int color=t1.getCurrentTextColor();

        imgText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(imageVis){
                    image.setVisibility(View.GONE);
                    imgText.setText("اضغط لأظهار الصورة");
                    imageVis=false;
                }else{
                    image.setVisibility(View.VISIBLE);
                    imgText.setText("اضغط لإخفاء الصورة");
                    imageVis=true;
                }
            }
        });

        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(i==1) {
                    hidden1.setVisibility(View.VISIBLE);
                }else {
                    hidden1.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        sp10.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(i==1) {
                    hidden2.setVisibility(View.VISIBLE);
                    hidden3.setVisibility(View.VISIBLE);
                }else {
                    hidden2.setVisibility(View.GONE);
                    hidden3.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        e1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                t1.setTextColor(color);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        e2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                t2.setTextColor(color);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        e3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                t3.setTextColor(color);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            int state=1;
            @Override
            public void onClick(View v) {
                boolean nullFound=false;
                if (e1.getText().toString().equals("")){
                    t1.setTextColor(Color.RED);
                    nullFound=true;
                }
                if (e2.getText().toString().equals("")){
                    t2.setTextColor(Color.RED);
                    nullFound=true;
                }
                if (e3.getText().toString().equals("")){
                    t3.setTextColor(Color.RED);
                    nullFound=true;
                }
                if(nullFound){
                    objectAnimator.start();
                    //sc.scrollTo(0,0);
                    Toast.makeText(mainActivity, "يجب عليك ملىء جميع البيانات!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(sp12.getSelectedItemId()==3 ||
                        sp13.getSelectedItemId()==3 ||
                        sp14.getSelectedItemId()==3 ){
                    state=3;
                } else if (sp12.getSelectedItemId()==2 ||
                        sp13.getSelectedItemId()==2 ||
                        sp14.getSelectedItemId()==2 ) {
                    state=2;
                }

                mainActivity.setState(state);
                mainActivity.addFragment(R.layout.fragment_result);
            }
        });

        return view;
    }
}