package com.example.project;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;


public class ResultFragment extends Fragment {
    MainActivity mainActivity;
    Button restart;
    LinearLayout l1,l2,l3;
    public void setActivity(MainActivity mainActivity){
        this.mainActivity=mainActivity;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view =inflater.inflate(R.layout.fragment_result, container, false);
        restart = view.findViewById(R.id.restart);
        l1=view.findViewById(R.id.l1);
        l2=view.findViewById(R.id.l2);
        l3=view.findViewById(R.id.l3);

        int state=mainActivity.getState();
        if(state==1){
            l1.setVisibility(View.VISIBLE);
        } else if (state==2) {
            l2.setVisibility(View.VISIBLE);
        }else if (state==3){
            l3.setVisibility(View.VISIBLE);
        }

        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mainActivity.addFragment(0);
            }
        });

        return view;
    }
}