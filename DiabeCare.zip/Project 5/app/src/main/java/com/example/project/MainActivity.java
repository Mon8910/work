package com.example.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;
    int state;

    public void setState(int state){
        this.state=state;
    }
    public int getState(){
        return this.state;
    }

    public void addFragment(long id) {
        if (id==0){
            fragmentManager.popBackStack(null,FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }
        if (id == R.layout.fragment_welcome) {
            fragmentTransaction = fragmentManager.beginTransaction();
            WelcomeFragment welcomeFragment = new WelcomeFragment();
            welcomeFragment.setActivity(this);
            fragmentTransaction.add(R.id.mainFrameLayout, welcomeFragment);
            fragmentTransaction.commit();
        }
        if (id == R.layout.fragment_main) {
            fragmentTransaction = fragmentManager.beginTransaction();
            MainFragment mainFragment = new MainFragment();
            mainFragment.setActivity(this);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.add(R.id.mainFrameLayout, mainFragment);
            fragmentTransaction.commit();
        }
        if (id == R.layout.fragment_result) {
            fragmentTransaction = fragmentManager.beginTransaction();
            ResultFragment resultFragment = new ResultFragment();
            resultFragment.setActivity(this);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.add(R.id.mainFrameLayout, resultFragment);
            fragmentTransaction.commit();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        fragmentManager = getSupportFragmentManager();

        addFragment(R.layout.fragment_welcome);
    }
}